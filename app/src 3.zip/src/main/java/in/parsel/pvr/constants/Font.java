package in.parsel.pvr.constants;

/**
 * Created by fixtureapps on 3/25/15.
 */
public enum Font {
    BOOK,
    MEDIUM,
    NARR_BOOK,
    NARR_MEDIUM,
    NARR_NEWS,
    NEWS,
    WIDE_MEDIUM,
    WIDE_NEWS,
    HELVETICA_LIGHT,
    HELVETICA_BOLD,
    GOTHAM_BOOK
}
