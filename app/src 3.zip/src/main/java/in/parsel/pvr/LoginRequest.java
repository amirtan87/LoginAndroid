package in.parsel.pvr;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by patch on 01/06/16.
 */

public class LoginRequest extends StringRequest {

    private static final String  LOGIN_REQUEST_URL = "https://dev.parsel.in/pbb/sec/login" ;
    private Map<String ,String> params ;

    public LoginRequest ( String username,  String password , Response.Listener<String>Listener) {

        super(Method.POST ,LOGIN_REQUEST_URL ,Listener ,null);
        params = new HashMap<>();
        params.put("username",username);
        params.put("password",password);

    }

    public Map<String, String> getParams() {
        return params;
    }
}
