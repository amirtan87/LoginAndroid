package in.parsel.pvr.model;

/**
 * Created by patch on 22/03/15.
 */
public class Vehicle {

    private long vehicleId;
    private String vehicleName;
    private String vehicleClass;
    private String vehicleNo;
    private int vehicleType;
    private String chassisNo;

    public void setVehicleId(long vehicleId) { this.vehicleId = vehicleId; }
    public void setVehicleName(String vehicleName) { this.vehicleName = vehicleName; }
    public void setVehicleClass(String vehicleClass) { this.vehicleClass = vehicleClass; }
    public void setVehicleNo(String vehicleNo) { this.vehicleNo = vehicleNo; }
    public void setVehicleType(int vehicleType) { this.vehicleType = vehicleType; }
    public void setChassisNo(String chassisNo) { this.chassisNo = chassisNo; }

    public long getVehicleId() { return vehicleId; }
    public String getVehicleName() { return vehicleName; }
    public String getVehicleClass() { return vehicleClass; }
    public String getVehicleNo() { return vehicleNo; }
    public int getVehicleType() { return vehicleType; }
    public String getChassisNo() { return chassisNo; }
}
