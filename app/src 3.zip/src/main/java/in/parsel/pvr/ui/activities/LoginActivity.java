package in.parsel.pvr.ui.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.util.ArrayMap;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;

import java.util.Map;

import in.parsel.pvr.R;
import in.parsel.pvr.constants.Constants;
import in.parsel.pvr.core.GsonRequest;
import in.parsel.pvr.model.input.LoginRequest;
import in.parsel.pvr.model.output.LoginOutput;
import in.parsel.pvr.utils.ModelUtil;

public class LoginActivity extends AppCompatActivity implements Response.Listener, Response.ErrorListener ,View.OnClickListener{


    private EditText etUsername;
    private EditText etPassword;
    private Button   bLogin ;
    private TextView registerLink ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        prepareControls();
        subscribeEvents();
    }

    protected void prepareControls() {
        etUsername   = (EditText) findViewById(R.id.etUsername);
        etPassword   = (EditText) findViewById(R.id.etPassword);
        bLogin       = (Button)findViewById(R.id.bLogin);
        registerLink = (TextView)findViewById(R.id.tvRegister);
        }

    protected void subscribeEvents() {
        bLogin.setOnClickListener(this);
        registerLink.setOnClickListener(this);
    }

        public void onClick(View view) {

        switch (view.getId()) {
            case R.id.bLogin:
                doLogin();
                Intent k = new Intent(this, UserAreaActivity.class);
                startActivity(k);
                //finish();
                break;

        }

    }


    private void doLogin(){
        final String username = etUsername.getText().toString();
        final String password = etPassword.getText().toString();

        try {

            Map<String, String> mHeaders = new ArrayMap<String, String>();
            RequestQueue queue = Volley.newRequestQueue(LoginActivity.this);
            queue.add(new GsonRequest(Constants.URL.LOGIN, Request.Method.POST, LoginOutput.class, mHeaders, getLoginJSON(username, password), this, this));
        }catch (Exception e){

        }
    }

    private String getLoginJSON(String username, String password) {

        LoginRequest request = new LoginRequest();
        request.setUsername(username);
        request.setPassword(password);
        return ModelUtil.serialize(request);
    }

    @Override
    public void onErrorResponse(VolleyError error) {


    }

    @Override
    public void onResponse(Object response) {

        LoginOutput loginOutput = (LoginOutput) response;
        if(loginOutput.getResponseCode().equalsIgnoreCase(LoginOutput.SUC_RESP_CODE)){

        }else {

            Context context = getApplicationContext();
            CharSequence text = "Wrong Credentails";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
    }
}
